<?php

include 'include/master.php';

?>
<!-- Reload Page Every 10sec -->
<!-- <meta http-eqiv="refresh" content="30"> -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="hero d-flex align-items-center section-bg">
    <div class="container">
      <div class="row justify-content-between gy-5">
        <div class="col-lg-5 order-2 order-lg-1 d-flex flex-column justify-content-center align-items-center align-items-lg-start text-center text-lg-start">
          <h2 data-aos="fade-up">Building Websites With <br>The Best UI/UX</h2>
          <p data-aos="fade-up" data-aos-delay="100">Your Business Growth is Our Prime Objective</p>
        </div>
        <div class="col-lg-5 order-1 order-lg-2 text-center text-lg-start">
          <img src="assets/img/logo/logo.png" class="img-fluid" alt="company logo" data-aos="zoom-out" data-aos-delay="300">
        </div>
      </div>
    </div>
  </section><!-- End Hero Section -->

  <main id="main">

    <section id="our-services" class="padding ptb-xs-60 text-center">
				<div class="container">
					<div class="row pb-60">
						<div class="col-sm-12 mb-20">
							<h2><span>Our</span> Services</h2>
							<span class="b-line"></span>
						</div>
					</div>
					<div class="row">

						<div class="col-md-4 col-sm-12">
							<div class="featured-item feature-bg-box mb-100 gray-bg sub-color_hover">
								<div class="icon">
									<i class="bi bi-easel sub-color"></i>
								</div>
								<div class="title text-uppercase">
									<h4>PROGRAMMING LANGUAGES</h4>
								</div>
								<div class="desc">
									Html/Css/Javascript, Php/Mysql.
								</div>
							</div>
						</div>
						<div class="col-md-4 col-sm-12">
							<div class="featured-item feature-bg-box gray-bg mb-100 sub-color_hover">
								<div class="icon">
									<i class="bi-currency-bitcoin sub-color"></i>
								</div>
								<div class="title text-uppercase">
									<h4>BUY/SELL CRYPTO CURRENCY</h4>
								</div>
								<div class="desc">
									We buy BTC, ETH, USDT, TRC20 TOKEN, BEP20 TOKEN and other top digital currency.
								</div>
							</div>
						</div>
						<div class="col-md-4 col-sm-12">
							<div class="featured-item feature-bg-box gray-bg mb-100 sub-color_hover">
								<div class="icon">
									<i class="bi-hand-thumbs-up sub-color"></i>
								</div>
								<div class="title text-uppercase">
									<h4> SOCIAL MEDIA BOOSTING</h4>
								</div>
								<div class="desc">
									We boost Facebook, Instagram, and Twitter account.
								</div>
							</div>
						</div>

					</div>

				</div>
			</section>
			<!--Our Services End -->

    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us section-bg">
      <div class="container" data-aos="fade-up">

        <div class="row gy-4">

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="why-box">
              <h3>Why Choose H3PTA TECH?</h3>
              <p>
                At Hepta Tech, We don't just give you the best, We ensure you become the best in your field 
                by providing your clients with in depth features of your business.
              </p>
              <div class="text-center">
                <!-- <a href="#why-us" class="more-btn">Learn More <i class="bx bx-chevron-right"></i></a> -->
              </div>
            </div>
          </div><!-- End Why Box -->

          <div class="col-lg-8 d-flex align-items-center">
            <div class="row">

              <div class="col-xl-4 col-md-4" data-aos="fade-up" data-aos-delay="200">
                <div class="icon-box d-flex flex-column justify-content-center align-items-center">
                  <i class="bi bi-file-earmark-lock"></i>
                  <h4>Our Exclusive Offer Of Protection</h4>
                  <p>We ensure that all possible loop holes are secured with encrypted sessions, cookies
                    and unwanted IP addresses or bots are denied access to our sites
                  </p>
                </div>
              </div><!-- End Icon Box -->

              <div class="col-xl-4 col-md-4" data-aos="fade-up" data-aos-delay="300">
                <div class="icon-box d-flex flex-column justify-content-center align-items-center">
                  <i class="bi bi-emoji-sunglasses"></i>
                  <h4>Our Unique UI/UX</h4>
                  <p>With great interface that allows users to navigate easily and spontaneous designs 
                    that illuminate the fug from the eyes.
                  </p>
                </div>
              </div><!-- End Icon Box -->

              <div class="col-xl-4 col-md-4" data-aos="fade-up" data-aos-delay="400">
                <div class="icon-box d-flex flex-column justify-content-center align-items-center">
                  <i class="bi bi-person-heart"></i>
                  <h4>Our Sense Of Humor, Towards Our Customers Budget</h4>
                  <p>We ensure that even with the lowest budget, our clients gets the best
                    from us
                  </p>
                </div>
              </div><!-- End Icon Box -->

            </div>
          </div>

        </div>

      </div>
    </section><!-- End Why Us Section -->

    <!-- ======= Menu Section ======= -->
    <section id="menu" class="menu">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <!-- <h2>Our Work</h2> -->
          <p>Check:: <span>Our Work</span></p>
        </div>

        <ul class="nav nav-tabs d-flex justify-content-center text-center" data-aos="fade-up" data-aos-delay="200">

          <li class="nav-item col-lg-3">
            <a class="nav-link active show" data-bs-toggle="tab" data-bs-target="#broker">
              <h4>BROKER</h4>
            </a>
          </li>

          <li class="nav-item col-lg-3">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#nft">
              <h4>NFT</h4>
            </a>

          <li class="nav-item col-lg-3">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#courierService">
              <h4>COURIER/SHIPPING</h4>
            </a>
          </li>

          <li class="nav-item col-lg-3">
            <a class="nav-link" data-bs-toggle="tab" data-bs-target="#banking">
              <h4>BANKING</h4>
            </a>
          </li>

        </ul>

        <div class="tab-content" data-aos="fade-up" data-aos-delay="300">

          <div class="tab-pane fade active show" id="broker">

            <div class="tab-header text-center">
              <!-- <p>Menu</p> -->
              <h3>BROKER</h3>
            </div>

            <div class="row gy-5">

              <div class="col-lg-4 menu-item">
                <a href="assets/img/portfolio/21.jpeg" class="glightbox"><img src="assets/img/portfolio/21.jpeg" class="few-product menu-img img-fluid" alt=""></a>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/portfolio/10.jpeg" class="glightbox"><img src="assets/img/portfolio/10.jpeg" class="few-product menu-img img-fluid" alt=""></a>             
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/portfolio/32.jpeg" class="glightbox"><img src="assets/img/portfolio/32.jpeg" class="few-product menu-img img-fluid" alt=""></a>                
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/portfolio/25.jpeg" class="glightbox"><img src="assets/img/portfolio/25.jpeg" class="few-product menu-img img-fluid" alt=""></a>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/portfolio/29.jpeg" class="glightbox"><img src="assets/img/portfolio/29.jpeg" class="few-product menu-img img-fluid" alt=""></a>
              </div><!-- Menu Item -->

            </div>
          </div><!-- End Starter Menu Content -->

          <div class="tab-pane fade" id="nft">

            <div class="tab-header text-center">
              <!-- <p>Menu</p> -->
              <h3>NFT</h3>
            </div>

            <div class="row gy-5">

              <div class="col-lg-4 menu-item">
                <a href="assets/img/portfolio/28.jpeg" class="glightbox"><img src="assets/img/portfolio/28.jpeg" class="few-product menu-img img-fluid" alt=""></a>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/portfolio/24.jpeg" class="glightbox"><img src="assets/img/portfolio/24.jpeg" class="few-product menu-img img-fluid" alt=""></a>
              </div><!-- Menu Item -->

            </div>
          </div><!-- End Menu Content -->

          <div class="tab-pane fade" id="courierService">

            <div class="tab-header text-center">
              <!-- <p>Menu</p> -->
              <h3>COURIER/SHIPPING</h3>
            </div>

            <div class="row gy-5">

            <div class="col-lg-4 menu-item">
                <a href="assets/img/portfolio/22.jpeg" class="glightbox"><img src="assets/img/portfolio/22.jpeg" class="few-product menu-img img-fluid" alt=""></a>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/portfolio/34.jpeg" class="glightbox"><img src="assets/img/portfolio/34.jpeg" class="few-product menu-img img-fluid" alt=""></a>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/portfolio/23.jpeg" class="glightbox"><img src="assets/img/portfolio/23.jpeg" class="few-product menu-img img-fluid" alt=""></a>
              </div><!-- Menu Item -->

            </div>
          </div><!-- End Lunch Menu Content -->

          <div class="tab-pane fade" id="banking">

            <div class="tab-header text-center">
              <!-- <p>Menu</p> -->
              <h3>BANKING</h3>
            </div>

            <div class="row gy-5">

              <div class="col-lg-4 menu-item">
                <a href="assets/img/portfolio/14.jpeg" class="glightbox"><img src="assets/img/portfolio/14.jpeg" class="few-product menu-img img-fluid" alt=""></a>
              </div><!-- Menu Item -->

              <div class="col-lg-4 menu-item">
                <a href="assets/img/portfolio/17.jpeg" class="glightbox"><img src="assets/img/portfolio/17.jpeg" class="few-product menu-img img-fluid" alt=""></a>
              </div><!-- Menu Item -->

              <!-- <div class="col-lg-4 menu-item">
                <a href="assets/img/portfolio/24.jpeg" class="glightbox"><img src="assets/img/portfolio/24.jpeg" class="few-product menu-img img-fluid" alt=""></a>
              </div> -->

            </div>
          </div><!-- End Dinner Menu Content -->

        </div>

      </div>
    </section><!-- End Menu Section -->

    <!-- ======= Certificate Section ======= -->
    <section id="gallery" class="gallery section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-header">
          <h2>Certificates</h2>
          <p>Our <span>Certificates</span></p>
        </div>

        <div class="gallery-slider swiper">
          <div class="swiper-wrapper align-items-center">
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/cert/Introduction to CSS_certificate.jpg"><img src="assets/img/cert/Introduction to CSS_certificate.jpg" class="img-fluid gallery-img" alt=""></a></div>
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/cert/Introduction to JavaScript_certificate.jpg"><img src="assets/img/cert/Introduction to JavaScript_certificate.jpg" class="img-fluid gallery-img" alt=""></a></div>
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/cert/PHP_certificate (1).jpg"><img src="assets/img/cert/PHP_certificate (1).jpg" class="img-fluid gallery-img" alt=""></a></div>
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/cert/JavaScript Intermediate_certificate.jpg"><img src="assets/img/cert/JavaScript Intermediate_certificate.jpg" class="img-fluid gallery-img" alt=""></a></div>
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/cert/Responsive Web Design_certificate.jpg"><img src="assets/img/cert/Responsive Web Design_certificate.jpg" class="img-fluid gallery-img" alt=""></a></div>
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/cert/CSS_certificate.jpg"><img src="assets/img/cert/CSS_certificate.jpg" class="img-fluid gallery-img" alt=""></a></div>
            <!-- <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/gallery/table2.jpg"><img src="assets/img/gallery/table2.jpg" class="img-fluid gallery-img" alt=""></a></div>
            <div class="swiper-slide"><a class="glightbox" data-gallery="images-gallery" href="assets/img/gallery/tv-stand2.jpg"><img src="assets/img/gallery/tv-stand2.jpg" class="img-fluid gallery-img" alt=""></a></div> -->
          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Gallery Section -->

    <!-- ======= Stats Counter Section ======= -->
    <section id="stats-counter" class="stats-counter">
      <div class="container" data-aos="zoom-out">

        <div class="row gy-4">

          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="stats-item text-center w-100 ">
              <span data-purecounter-start="0" data-purecounter-end="72" data-purecounter-duration="1" class="purecounter"></span>
              <p>Happy Clients</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="stats-item text-center w-100 ">
              <span data-purecounter-start="0" data-purecounter-end="87" data-purecounter-duration="1" class="purecounter"></span>
              <p>Finished Projects</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="stats-item text-center w-100 ">
              <span data-purecounter-start="0" data-purecounter-end="4" data-purecounter-duration="1" class="purecounter"></span>
              <p>Team</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="stats-item text-center w-100 ">
              <span data-purecounter-start="0" data-purecounter-end="4870" data-purecounter-duration="1" class="purecounter"></span>
              <p>Hours of Work</p>
            </div>
          </div><!-- End Stats Item -->

        </div>

      </div>
    </section><!-- End Stats Counter Section -->

    

  </main><!-- End #main -->


  <?php

  include 'include/footer1.php';

  ?>